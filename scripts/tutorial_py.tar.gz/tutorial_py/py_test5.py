#!/usr/bin/env python
import rospy
import random
from std_msgs.msg import Float32



def publish_sensor_data():
    rospy.init_node('temp_sensor_node')
    pub=rospy.Publisher('temperature',Float32,queue_size=10)
    
    while True:
        temp_data=28.0+random.random()+2
        pub.publish(temp_data)
        rospy.loginfo("Temperature is : %f" %temp_data)
        rospy.sleep(1)
        
        if rospy.is_shutdown():
            rospy.loginfo('temp_sensor_node is shut down')
            break


if __name__=='__main__':
    publish_sensor_data()