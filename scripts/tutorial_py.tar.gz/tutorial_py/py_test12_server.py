#!/usr/bin/env python
import rospy
from my_robotics.srv import my_sum,my_sumResponse

def add_two_num(req):
    return my_sumResponse(req.a+req.b)

def service():
    rospy.init_node('addtwonum_node')
    rospy.Service('add_two_num_service',my_sum,add_two_num)
    rospy.spin()

if __name__=='__main__':
    service()