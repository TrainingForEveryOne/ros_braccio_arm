#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from my_robotics.msg import my_msg


def talker():
    rospy.init_node('my_seventh_node')
    pub=rospy.Publisher('greetings',my_msg,queue_size=10)
    i=0

    while True:
        msg=my_msg()
        msg.name="Ally"
        msg.greetings="Hello %s" %i
        pub.publish(msg)
        rospy.loginfo('I publish a message!')

        i=i+1
        rospy.sleep(1)
        if rospy.is_shutdown():
            rospy.loginfo('node is shut down')
            break


if __name__=='__main__':
    talker()
