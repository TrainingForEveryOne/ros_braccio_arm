#!/usr/bin/env python
import sys
import rospy
from my_robotics.srv import my_service,my_serviceResponse


def on_off_request(req):
    rospy.wait_for_service('on_off_service')
    req_service=rospy.ServiceProxy("on_off_service",my_service)
    print(req_service(req))


if __name__=='__main__':
    req=int(sys.argv[1])
    result=on_off_request(req)
