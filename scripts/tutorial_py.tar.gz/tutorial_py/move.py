#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist


def move():
    nh=rospy.init_node("move_turtle")
    pub=rospy.Publisher("/turtle1/cmd_vel",Twist,queue_size=10)

    vel=Twist()
    vel.linear.x=1.0
    vel.linear.y=0.0
    vel.linear.z=0.0
    vel.angular.x=0.0
    vel.angular.y=0.0
    vel.angular.z=1.0

    while True:
        pub.publish(vel)
        rospy.sleep(1)
        if rospy.is_shutdown():
            rospy.loginfo("node is shutdown")
            break

if __name__=='__main__':
    try:
        move()
    except rospy.ROSInterruptException: pass
