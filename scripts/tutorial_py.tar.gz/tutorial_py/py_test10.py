#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32
from my_robotics.msg import iot_sensor


def call_back(msg):
    rospy.loginfo('Received data: Id %s' %msg.id)
    rospy.loginfo('Received data: Temperature is %f' %msg.temperature)

def receiver_sensor_node():
    rospy.init_node('receiver_sensor_node')
    sub=rospy.Subscriber('temperature',iot_sensor,call_back)
    rospy.spin()


if __name__=='__main__':
    receiver_sensor_node()