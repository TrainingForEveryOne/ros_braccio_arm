#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from my_robotics.msg import my_msg


def call_back(msg):
    rospy.loginfo("I am %s" %msg.name)
    rospy.loginfo(msg.greetings)

def listener():
    rospy.init_node('my_eighth_node')
    sub=rospy.Subscriber('greetings',my_msg,call_back)
    rospy.spin()


if __name__=='__main__':
    listener()