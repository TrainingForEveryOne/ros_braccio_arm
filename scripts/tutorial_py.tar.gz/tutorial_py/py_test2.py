#!/usr/bin/env python
import rospy
from std_msgs.msg import String

def talker():
    i=0
    rospy.init_node('my_second_node')
    while True:
        rospy.loginfo("Hello World %s" %i)
        i=i+1
        rospy.sleep(1)
        if rospy.is_shutdown():
            rospy.loginfo("node is shut down")
            break

if __name__=='__main__':
    talker()