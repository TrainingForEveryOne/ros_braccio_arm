#!/usr/bin/env python
import rospy
import random
from std_msgs.msg import Float32
from my_robotics.msg import iot_sensor


def publish_sensor_data():
    rospy.init_node('temp_sensor_node')
    pub=rospy.Publisher('temperature',iot_sensor,queue_size=10)
    
    while True:
        temp_data=iot_sensor()
        temp_data.id=1
        temp_data.temperature=28.0+random.random()+2

        pub.publish(temp_data)
        rospy.loginfo("Id : %s" %temp_data.id)
        rospy.loginfo("Temperature is : %f" %temp_data.temperature)
        rospy.sleep(1)
        
        if rospy.is_shutdown():
            rospy.loginfo('temp_sensor_node is shut down')
            break


if __name__=='__main__':
    publish_sensor_data()