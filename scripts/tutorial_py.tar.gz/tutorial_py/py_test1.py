#!/usr/bin/env python
import rospy

def node_off():
    rospy.loginfo("node is shut down")

rospy.init_node('my_first_node')
print("Start the node")
rospy.spin()

rospy.on_shutdown(node_off)

