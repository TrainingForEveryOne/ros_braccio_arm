#!/usr/bin/env python
import sys
import rospy
from my_robotics.srv import my_sum,my_serviceResponse

def req_service(num1,num2):
    rospy.wait_for_service("add_two_num_service")
    add_service=rospy.ServiceProxy("add_two_num_service",my_sum)
    print("Adding %i and %i are : %i " %(num1,num2,add_service(num1,num2).sum))

if __name__=='__main__':
    num1=int(sys.argv[1])
    num2=int(sys.argv[2])
    req_service(num1,num2)