#!/usr/bin/env python
import rospy
from actionlib import SimpleActionClient
from my_robotics.msg import my_actionAction,my_actionGoal,my_actionResult,my_actionFeedback
import sys

def fibonacci_client():
    # Creates the SimpleActionClient, passing the type of the action
    # (FibonacciAction) to the constructor.
    client = SimpleActionClient('fibonacci', my_actionAction)
    client.wait_for_server()
    client.send_goal(my_actionGoal(order=10))
    client.wait_for_result()

    return client.get_result()  # A FibonacciResult

if __name__ == '__main__':
    try:
        # Initializes a rospy node so that the SimpleActionClient can
        # publish and subscribe over ROS.
        rospy.init_node('fibonacci_client_py')
        result = fibonacci_client()
        print("Result:", ', '.join([str(n) for n in result.sequence]))
    except rospy.ROSInterruptException:
       pass