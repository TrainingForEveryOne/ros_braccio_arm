#!/usr/bin/env python
import rospy
from std_msgs.msg import String

def call_back(msg):
    rospy.loginfo(msg.data)

def listener():
    rospy.init_node('my_fourth_node')
    sub=rospy.Subscriber('greeting',String,call_back)
    rospy.spin()

if __name__=='__main__':
    listener()