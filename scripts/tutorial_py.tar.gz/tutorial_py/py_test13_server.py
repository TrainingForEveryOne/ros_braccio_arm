#!/usr/bin/env python
import rospy
import actionlib
from actionlib import SimpleActionServer
from my_robotics.msg import my_actionAction,my_actionGoal,my_actionResult,my_actionFeedback


class FibonacciActionServer(object):
    # create messages that are used to publish feedback/result
    feedback = my_actionFeedback()
    result = my_actionResult()

    def __init__(self, name):
        self.action_name = name
        self.action_server = SimpleActionServer(self.action_name, my_actionAction, execute_cb=self.execute_cb, auto_start = False)
        self.action_server.start()
      
    def execute_cb(self, goal):
        # helper variables
        r = rospy.Rate(1)
        
        # append the seeds for the fibonacci sequence
        self.feedback.sequence = []
        self.feedback.sequence.append(0)
        self.feedback.sequence.append(1)
        
        # publish info to the console for the user
        rospy.loginfo('%s: Executing, creating fibonacci sequence of order %i with seeds %i, %i' % (self.action_name, goal.order, self.feedback.sequence[0], self.feedback.sequence[1]))
        
        # start executing the action
        for i in range(1, goal.order):
            self.feedback.sequence.append(self.feedback.sequence[i] + self.feedback.sequence[i-1])
            # publish the feedback
            rospy.loginfo('publishing feedback ... %i' %i)
            self.action_server.publish_feedback(self.feedback)
            # this step is not necessary, the sequence is computed at 1 Hz for demonstration purposes
            r.sleep()

        if (self.feedback.sequence.count>2):
            print('Fibonacci success')
            self.result.sequence = self.feedback.sequence
            self.action_server.set_succeeded(self.result)
        
if __name__ == '__main__':
    rospy.init_node('fibonacci')
    # my_server=SimpleActionServer('Fibo_server',my_actionAction,execute_cb=fibo_execute, auto_start = False)
    # my_server.start()

    #fibonacci_gen_server()
    server = FibonacciActionServer(rospy.get_name())
    rospy.spin()